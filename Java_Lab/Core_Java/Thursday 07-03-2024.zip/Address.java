/*Define a class Address representing an address with attributes such as street, city, state, and zip code. 
Provide constructors to initialize these attributes.*/
package Pgm_practice;
import java.util.Constuctors;

public class Address {
    private String street;
    private String city;
    private String state;
    private String zipCode;

    
    public Address(String street, String city, String state, String zipCode) {
        this.street = street;
        this.city = city;
        this.state = state;
        this.zipCode = zipCode;
    }

   
    public String getStreet() {
        return street;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public String getZipCode() {
        return zipCode;
    }

    
    public void setStreet(String street) {
        this.street = street;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

         public static void main(String[] args) {
			Address address = new Address("123 Main St", "Springfield", "IL", "12345");
			System.out.println("Street: " + address.getStreet());
			System.out.println("City: " + address.getCity());
			System.out.println("State: " + address.getState());
			System.out.println("Zip Code: " + address.getZipCode());

			address.setZipCode("54321");
			System.out.println("Updated Zip Code: " + address.getZipCode());
			
		}
}
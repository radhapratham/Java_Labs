/*Create a program in java to implement multilevel inheritance and hierarchical inheritance .

Take classes like : Doctor , Surgeon and Nurse

Create methods and show method overriding*/

class Doctor {
    void diagnose() {
        System.out.println("Doctor can diagnose diseases.");
    }
}


class Surgeon extends Doctor {
    
    @Override
    void diagnose() {
        System.out.println("Surgeon can diagnose and perform surgeries.");
    }
    
    void operate() {
        System.out.println("Surgeon can perform surgeries.");
    }
}


class Nurse extends Doctor {
    void assist() {
        System.out.println("Nurse can assist doctors.");
    }
}

public class Main {
    public static void main(String[] args) {
        
        Surgeon john = new Surgeon();
        john.diagnose(); 
        john.operate(); 
        
        
        Nurse lily = new Nurse();
        lily.diagnose();
        lily.assist(); 
    }
}
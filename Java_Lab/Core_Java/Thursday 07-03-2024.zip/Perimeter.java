package Pgm_practice;
import java.util.Perimeter;

public class PerimeterExample {
    
    double calculatePerimeter(double side) {
        return 4 * side;
    }
    
   
    double calculatePerimeter(double length, double width) {
        return 2 * (length + width);
    }
    
    double calculatePerimeters(double radius) {
        return 2 * (22.0/7.0) * radius;
    }
    
    public static void main(String[] args) {
        Perimeter perimeterCalculator = new Perimeter();
        
        double squarePerimeter = perimeterCalculator.calculatePerimeter(5);
        System.out.println("Perimeter of square: " + squarePerimeter);
        
        double rectanglePerimeter = perimeterCalculator.calculatePerimeter(4, 6);
        System.out.println("Perimeter of rectangle: " + rectanglePerimeter);
        
        double circlePerimeter = perimeterCalculator.calculatePerimeter(3);
        System.out.println("Perimeter of circle: " + circlePerimeter);
    }
}
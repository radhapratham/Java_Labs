/*.Write a program using ArrayDeque to add book names and add,delete the values from both ends of que.*/

package com.collectionexample;

import java.util.ArrayDeque;

public class BookQueueExample 
{
    public static void main(String[] args)
    {
        ArrayDeque<String> bookQueue = new ArrayDeque<>();

        bookQueue.add("Book1");
        bookQueue.add("Book2");
        bookQueue.add("Book3");

        System.out.println("Initial Queue: " + bookQueue);

        String newBookFront = "Book0";
        bookQueue.addFirst(newBookFront);
        System.out.println("After adding '" + newBookFront + "' at the front: " + bookQueue);

        String newBookEnd = "Book4";
        bookQueue.addLast(newBookEnd);
        System.out.println("After adding '" + newBookEnd + "' at the end: " + bookQueue);

        String removedFromFront = bookQueue.removeFirst();
        System.out.println("Removed from the front: " + removedFromFront);
        System.out.println("After removing from the front: " + bookQueue);

        String removedFromEnd = bookQueue.removeLast();
        System.out.println("Removed from the end: " + removedFromEnd);
        System.out.println("After removing from the end: " + bookQueue);
    }
}
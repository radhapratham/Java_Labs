/*.Write a program using TreeSet insert Integer values and print them.*/


package com.collectionexample;

import java.util.TreeSet;

public class TreeSetExample1 
{
    public static void main(String[] args)
    {
        TreeSet<Integer> treeSet = new TreeSet<>();

        treeSet.add(10);
        treeSet.add(30);
        treeSet.add(80);
        treeSet.add(50);
        treeSet.add(40);

        System.out.println("TreeSet values: " + treeSet);
    }
}
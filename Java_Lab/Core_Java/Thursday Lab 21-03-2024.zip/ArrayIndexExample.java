/*Create a program with a logic that throws the ArrayIndexOutOfBoundsException

while accessing elements in an array.*/


public class ArrayIndexExample {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};

        for (int i = 0; i <= array.length; i++) {
            try {
                System.out.println(array[i]);
            } 
            catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("ArrayIndexOutOfBoundsException caught!");
            }
        }
    }
}
/* Create two thread.one thread is finding the average of the first 10 numbers and

another thread is printing the square of the number stored in array arr={1,20,50,15,30}

and make sure both threads can execute simultaneously.*/


public class Threads {
    public static void main(String[] args) {
        
        Thread averageThread = new Thread(new AverageCalculator());
        
        
        Thread squareThread = new Thread(new SquarePrinter());

        
        averageThread.start();
        squareThread.start();
    }
}

class AverageCalculator implements Runnable {
    @Override
    public void run() {
        int sum = 0;
        for (int i = 1; i <= 10; i++) {
            sum += i;
        }
        double average = (double) sum / 10;
        System.out.println("Average of the first 10 numbers: " + average);
    }
}

class SquarePrinter implements Runnable {
    private int[] arr = {1, 20, 50, 15, 30};

    @Override
    public void run() {
        System.out.print("Squares of numbers in the array: ");
        for (int num : arr) {
            System.out.print(num * num + " ");
        }
        System.out.println();
    }
}
/*2. Create a class named Book with attributes title, author, ISBN, and price. Include methods to get and set the attributes.*/



public class Book {
    private String title;
    private String author;
    private String ISBN;
    private double price;

    public Book(String title, String author, String ISBN, double price) {
        this.title = title;
        this.author = author;
        this.ISBN = ISBN;
        this.price = price;
    }

    
    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getISBN() {
        return ISBN;
    }

    public double getPrice() {
        return price;
    }

    
    public void setPrice(double price) {
        this.price = price;
    }

    public static void main(String[] args) {
        Book book = new Book("The Guide", "R.N.Narayan ", "91-9578999196", 9.99);
        System.out.println("Title: " + book.getTitle());
        System.out.println("Author: " + book.getAuthor());
        System.out.println("ISBN: " + book.getISBN());
        System.out.println("Price: $" + book.getPrice());

        
        book.setPrice(12.99);
        System.out.println("New price: $" + book.getPrice());
    }
}
/*Create a class named Employee with attributes name, employeeId, designation, and salary.   Include a method calculateBonus() that returns 5% of the salary as bonus*/


public class Employee {
    private String name;
    private int employeeId;
    private String designation;
    private double salary;

   
    public Employee(String name, int employeeId, String designation, double salary) {
        this.name = name;
        this.employeeId = employeeId;
        this.designation = designation;
        this.salary = salary;
    }

    
    public double calculateBonus() {
        return 0.05 * salary;
    }

    
    public String getName() {
        return name;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getDesignation() {
        return designation;
    }

    public double getSalary() {
        return salary;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setSalary(double salary) {
        this.salary = salary;
        
    }
     public static void main(String[] args) {
          Employee emp = new Employee("Sweety", 12345, "Software Engineer", 50000.0);
           System.out.println("Employee: " + emp.getName());
           System.out.println("Designation: " + emp.getDesignation());
           System.out.println("Salary: $" + emp.getSalary());
           System.out.println("Bonus: $" + emp.calculateBonus());

           emp.setSalary(55000.0);
           System.out.println("New salary: $" + emp.getSalary());
           System.out.println("New bonus: $" + emp.calculateBonus());
    }
         
}
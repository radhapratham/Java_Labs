import java.util.Scanner;

class Bmi
{
	float bmi,height,weight;
	void getData()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter Height in M: "); 
		height=sc.nextFloat();
		System.out.print("Enter Weight in Kg: "); 
		weight=sc.nextFloat();
	}
	void putData()
	{
		
        System.out.println("Height: "+height+" Weight: "+weight);
    }
	void bmiCalculate()
	{
		bmi=weight/(height*height); 
		System.out.println("Body Mass Index= "+bmi);
		if(bmi<18.0)
		{
			System.out.println("Underweight");
		}
		if(bmi>=18.5 && bmi<=24.9)
		{
			System.out.println("Normal");
		}
		else if(bmi>=25.0 && bmi<=29.9)
		{
			System.out.println("Overweight");
		}
		else
		{
			System.out.println("Obese");
		}
	}	
}
class BmiCalculate 
{
	public static void main(String args[]) 
	{
		Bmi b=new Bmi(); 
		
		b.getData();
		b.putData();
		b.bmiCalculate();	
	}
}
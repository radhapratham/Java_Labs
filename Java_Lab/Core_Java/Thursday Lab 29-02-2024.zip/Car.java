/*4. Create a class named Car with attributes make, model, year, and color. 
Include a method start() that prints "Car started" and a method stop() that prints "Car stopped".*/



class Car
{
	
	String make;
	String model;
	int year;
	String color;
	Car() 
	{
		this.make="Tata";
		this.model="Nexon";
		this.year=2020;
		this.color="Black";
	}
	void putData()
	{
		
        System.out.println("Car Details=  Make: "+this.make+" Model: "+this.model+" Year: "+this.year+" Color: "+this.color);
    }
	void start() 
	{
		System.out.println("Car started");
	}
	void stop() 
	{
		System.out.println("Car stopped");
	}
}
class CarDetails 
{
	public static void main(String args[])  
	{
		Car c=new Car(); 
		c.putData();
		c.start();
		c.stop();
	}
}
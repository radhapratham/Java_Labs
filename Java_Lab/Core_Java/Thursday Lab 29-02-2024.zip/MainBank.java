/*Implement a bank account class showing method overloading with methods for deposit, withdrawal
and balance inquiry.
use method overloading to handle different types of transactions.*/


class Bank 
{
	int b_acc_no,pin_no;
	String b_name,cards_type,customer_name;
	double balance,total_balance,deposit_amount,withdrawal_amount;
	Bank(double balance)
	{
		System.out.println("Bank Balance of Account");
		this.balance=balance;
		System.out.println("Bank Balance Display "+balance);
	}
	void transaction(String customer_name,int b_acc_no, String b_name,double deposit_amount)
	{
		System.out.println("The Deposit Amount of Bank ");
		this.customer_name=customer_name;
		this.b_acc_no=b_acc_no;
		this.b_name=b_name;
		this.deposit_amount=deposit_amount;
		System.out.println("Customer Name "+customer_name);
		System.out.println("Bank Account Number "+b_acc_no);
		System.out.println("Bank Name "+b_name);
		System.out.println("Deposit Amount "+deposit_amount);
		this.total_balance=balance+deposit_amount;
		System.out.println("Total Amount "+total_balance);
	}
	void transaction(int pin_no,String cards_type ,double withdrawal_amount)
	{
		System.out.println("The Withdrawal the Bank Balance through the  Account");	
		this.pin_no=pin_no;
		this.cards_type=cards_type;
		this.withdrawal_amount=withdrawal_amount;
	
		System.out.println("Card PIN Number "+pin_no);
		System.out.println("Card Use Type "+cards_type);
		System.out.println("How many Amount Withdrawal "+withdrawal_amount);
		this.total_balance=balance-withdrawal_amount;
		System.out.println("Total Amount "+total_balance);
	}    
	
	void transaction(int b_acc_no,double total_balance)
	{
		System.out.println("The Bank Balance Inquiry of Account");
		
		this.b_acc_no=b_acc_no;
		
		this.total_balance=total_balance;
		
		System.out.println("Bank Account Number "+b_acc_no);
		
		System.out.println("Total Amount "+total_balance);
	}
}
class MainBank
{
	public static void main(String args[])
	{
	Bank b=new Bank(35000);
	b.transaction("Amol chodari",254163987,"State of india",350);
	b.transaction(5254,"debit card",1500);
	b.transaction(2145789632,"Bank of india",33850);
	b.transaction(2145789632,33850);
	}
}
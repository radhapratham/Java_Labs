/*1.WAP for creating the mini calculator. you have to perform an operation on the basis of 
user choice until the user press yes to continue(add, mul, sub, div)*/



import java.util.Scanner;
 class MiniCalculator
 {
	public static void main(String args[])
	{
		char input;
		do
		{
			int result;
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the Frist Number:");
			int num1=sc.nextInt();
			System.out.println("Enter the Second Number:");
			int num2=sc.nextInt();
			System.out.println("Enter the Operation +,-,*,/:");
			String operation=sc.next();
			if(operation.equals("+"))
			{
				result=num1+num2;
				System.out.println("Addition of two numbers:"+result);
			}
			else if(operation.equals("-"))
			{
				result=num1-num2;
				System.out.println("Substraction of two numbers:"+result);
			}
			else if(operation.equals("*"))
			{
				result=num1*num2;
				System.out.println("Multiplication of two numbers:"+result);
			}
			else if(operation.equals("/"))
			{
				result=num1/num2;
				System.out.println("Division of two numbers:"+result);
			}
			System.out.println("Would you like to continue?(yes/no)");
		    input=sc.next().charAt(0);
		}while(input== 'y' || input== 'Y');
		System.out.println("THANK YOU!");
		//sc.close();
	}
}
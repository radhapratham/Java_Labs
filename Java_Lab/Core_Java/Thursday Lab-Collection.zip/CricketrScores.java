/* write a program in Java to create a Map Interface where we can store the cricketer name in it along with his scores and search for the batsman name and display his score.*/

import java.util.HashMap;
import java.util.Map;

public class CricketerScores {
    public static void main(String[] args) {
       
        Map<String, Integer> cricketerScores = new HashMap<>();

        
        cricketerScores.put("Virat Kohli", 120);
        cricketerScores.put("Rohit Sharma", 85);
        cricketerScores.put("Steve Smith", 102);
        cricketerScores.put("Kane Williamson", 78);
        cricketerScores.put("Joe Root", 95);

        
        String batsmanName = "Virat Kohli";
        if (cricketerScores.containsKey(batsmanName)) {
            int score = cricketerScores.get(batsmanName);
            System.out.println(batsmanName + "'s score is: " + score);
        } else {
            System.out.println("Batsman not found in the records.");
        }
    }
}
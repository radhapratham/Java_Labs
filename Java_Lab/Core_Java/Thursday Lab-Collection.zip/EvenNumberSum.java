/*Write a Java program that calculates the sum of all even numbers present in an

ArrayList of integers.

Sample Input:

2,5,8,10,15 */



import java.util.ArrayList;

public class EvenNumberSum {
    public static void main(String[] args) {
        
        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(2);
        numbers.add(5);
        numbers.add(8);
        numbers.add(10);
        numbers.add(15);

        
        int sum = 0;

       
        for (int number : numbers) {
            if (number % 2 == 0) {
                sum += number;
            }
        }

        
        System.out.println("Sum of even numbers is: " + sum);
    }
}
/*Write a Java program to check whether a HashMap contains key-value mappings (empty) or not.*/


import java.util.HashMap;

public class HashMapChecker {
    public static void main(String[] args) {
        // Create a HashMap
        HashMap<String, String> hashMap = new HashMap<>();

        // Check if the HashMap is empty
        if (hashMap.isEmpty()) {
            System.out.println("HashMap is empty.");
        } else {
            System.out.println("HashMap is not empty.");
        }
    }
}
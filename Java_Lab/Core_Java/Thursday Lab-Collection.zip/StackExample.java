/* Write a program to declare stack store 10 element into it.Remove 4 element 
  from stack and display it */

package Pgm_practice;
import java.util.Stack;
public class StackExample 
{
	public static void main(String[] args) 
	{
		Stack<Integer> s = new Stack<Integer>(); 
		for(int i=1;i<10;i++)
		{
			s.push(i);
		}
		System.out.println("Stack element before removing :"+s);
		System.out.println("Removed element : ");
		for(int i=0;i<4;i++)
		{
			System.out.println(s.pop());
		}
		System.out.println("Stack element After removing :"+s);         
	  }  

}

/* 
OUTPUT : 
Stack element before removing :[1, 2, 3, 4, 5, 6, 7, 8, 9]
Removed element : 
9
8
7
6
Stack element After removing :[1, 2, 3, 4, 5]    
*/

 
 


/*Write a program using Vector to store the list of students details and print the details.*/


package com.collectionexample;

import java.util.Vector;

class Student 
{
    public int id;
    public String name;
    public String email;
    public String contact;

    public Student(int id, String name, String email, String contact) 
    {
        this.id = id;
        this.name = name;
        this.email = email;
        this.contact = contact;
    }
}

public class VectorExample1 
{
    public static void main(String[] args) 
    {
        Vector<Student> students = new Vector<>();

        students.add(new Student(1, "Aaaru", "aaru@gmail.com", "5253653532"));
        students.add(new Student(2, "Akshu", "Akshu@gmail.com", "9876543210"));
        students.add(new Student(3, "Bhanu", "bhanu@gamil.com", "4567890123"));
        students.add(new Student(3, "Sony", "sony@gamil@gamil.com", "6523421472"));

        for (Student student : students) 
        {
            System.out.println("ID: " + student.id);
            System.out.println("Name: " + student.name);
            System.out.println("Email: " + student.email);
            System.out.println("Contact: " + student.contact);
            System.out.println();
        }
    }
}